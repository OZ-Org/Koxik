export const emotes = {
	badges: {
		developer: '<:developer:1422371870287593585>',
		small_dev: '<:small_dev:1422371833394495528>',
		booster: '<:booster:1422371858077978644>',
		bot: '<:bot:1422371848280215562>',
		owner: '<:owner:1422371865472798720>',
		patner: '<:patner:1422371844304142449>',
		staff: '<:staff:1422371851618877520>',
		beta: '<:beta_tester:1422422201273024715>',
	},
	misc: {
		suspect: '<:breadsus:1422770743451844668>',
	},
};
