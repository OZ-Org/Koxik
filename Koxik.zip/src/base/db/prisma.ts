import { PrismaClient } from '../../base/db/generated/prisma/client.js';

export const prisma = new PrismaClient();
