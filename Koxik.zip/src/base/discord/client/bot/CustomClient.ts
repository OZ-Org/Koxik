import { Client, type ClientOptions } from 'discord.js';

/**
 * Classe customizada que estende o Client padrão do Discord.js
 * e adiciona propriedades globais do bot.
 */
export class KoxikClient extends Client {
	public owners: string[];

	constructor(options: ClientOptions, owners?: string[]) {
		super(options);
		this.owners = owners ?? [];
	}
}
